# Avetisian & Grigorian

Engagement invitation · 26 November 2026 · 17:30 · Paradise Hall

Upload index.html, couple.jpeg and .nojekyll to the root of your GitHub repository. Enable GitHub Pages in Settings → Pages → Deploy from a branch → main → / (root).

To replace the photograph, replace couple.jpeg with a new photograph using the same filename. All styling and interaction code is inside index.html.
